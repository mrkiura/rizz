# Rizz

A framework for building web applications with Python

Implements the Web Server Gateway Interface (WSGI)
